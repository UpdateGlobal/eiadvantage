$(function() {
	'use strict';
	new cbpScroller( document.getElementById( 'cbp-so-scroller' ) );

});