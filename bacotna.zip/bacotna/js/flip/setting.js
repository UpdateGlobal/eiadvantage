(function ($) {
	"use strict";
      $(".flip-wrapp").flip({
        trigger: "hover"
      });
}(jQuery));