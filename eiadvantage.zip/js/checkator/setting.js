(function($) {
	'use strict';
	var inputStyle = $("input[type='radio'], input[type='checkbox']");
	inputStyle.checkator();
})(jQuery);