$(document).ready(function(e) {
	$("#tech").msDropdown();
});